package com.pratiksha.springbootcrudexample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


import com.pratiksha.springbootcrudexample.model.Students;
import com.pratiksha.springbootcrudexample.service.StudentService;

public class StudentsController{
	
	@Autowired  
	StudentService studentService;  
	
	@GetMapping("/student")  
	private List<Students> getAllStudent()   
	{  
	return studentService.getAllStudent();

	}  
	
	@GetMapping("/student/{studentid}")  
	private Students getStudent(@PathVariable("studentid") int studentid)   
	{  
	return studentService.getStudentById(studentid);  
	} 
	
	@DeleteMapping("/student/{studentid}")  
	private void deleteStudent(@PathVariable("studentid") int studentid)   
	{  
		studentService.delete(studentid);  
	}  
	
	
	@PostMapping("/students")    
	private int saveStudent(@RequestBody Students students)   
	{  
	studentService.saveOrUpdate(students);  
	
	return students.getStudentid();  
	}  
	
	@PutMapping("/student")  
	private Students update(@RequestBody Students students)   
	{  
	studentService.saveOrUpdate(students);  
	return students;   
	
	}
	
}