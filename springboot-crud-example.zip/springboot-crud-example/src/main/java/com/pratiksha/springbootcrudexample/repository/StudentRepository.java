package com.pratiksha.springbootcrudexample.repository;

import org.springframework.data.repository.CrudRepository;

import com.pratiksha.springbootcrudexample.model.Students;

public interface StudentRepository extends CrudRepository<Students, Integer> {

}
