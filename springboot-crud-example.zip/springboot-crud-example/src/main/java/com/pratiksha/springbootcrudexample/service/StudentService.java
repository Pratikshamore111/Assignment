package com.pratiksha.springbootcrudexample.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.pratiksha.springbootcrudexample.model.Students;
import com.pratiksha.springbootcrudexample.repository.StudentRepository;



public class StudentService {
	
	@Autowired  
	StudentRepository studentRepository;

	public List<Students> getAllStudent()
	{  
	List<Students> students = new ArrayList<Students>();  
	studentRepository.findAll().forEach(student1 -> students.add(student1));  
	return students;  
	}  

	public Students getStudentById(int id)   
	{  
	   return studentRepository.findById(id).get();  
	}  
	public void saveOrUpdate(Students students)   
	{  
	    studentRepository.save(students);  
	}  
	public void delete(int id)   
	{  
	    studentRepository.deleteById(id);  
	}  
	public void update(Students students, int studentid)   
	{  
	   studentRepository.save(students);  
	}  
}
